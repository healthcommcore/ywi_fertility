editArea.add_lang("pl",{
test_select: "wybierz tag",
test_but: "test"
});
